// static/js/main.js

// ── Sidebar toggle (mobile) ──────────────────────────
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

// Auto-dismiss flash alerts after 4 seconds
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.alert.alert-dismissible').forEach(el => {
    setTimeout(() => {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(el);
      bsAlert?.close();
    }, 4000);
  });

  // Highlight active sidebar link
  const path = window.location.pathname;
  document.querySelectorAll('.sidebar-nav a').forEach(link => {
    if (link.getAttribute('href') === path) {
      link.classList.add('active');
    }
  });
});

// ── Confirm delete helper ────────────────────────────
function confirmDelete(formEl, msg) {
  if (confirm(msg || 'Are you sure you want to delete this record?')) {
    formEl.submit();
  }
}
