# database/db_config.py
import mysql.connector
from mysql.connector import Error
import os

DB_CONFIG = {
    'host':     os.environ.get('MYSQL_HOST', 'localhost'),
    'user':     os.environ.get('MYSQL_USER', 'root'),
    'password': os.environ.get('MYSQL_PASSWORD', '#Hf1214158'),
    'database': os.environ.get('MYSQL_DB', 'fraud_detection_db'),
    'port':     int(os.environ.get('MYSQL_PORT', 3306)),
}


def get_connection():
    """Return a new MySQL connection."""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        if conn.is_connected():
            return conn
    except Error as e:
        print(f"[DB ERROR] Could not connect to MySQL: {e}")
        raise


def execute_query(query: str, params: tuple = (), fetch: bool = False):
    """
    Execute a single query.
    - fetch=True  → returns list of row dicts
    - fetch=False → commits and returns lastrowid
    """
    conn = None
    cursor = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params)
        if fetch:
            return cursor.fetchall()
        conn.commit()
        return cursor.lastrowid
    except Error as e:
        if conn:
            conn.rollback()
        print(f"[DB ERROR] Query failed: {e}")
        raise
    finally:
        if cursor:
            cursor.close()
        if conn and conn.is_connected():
            conn.close()


def execute_many(query: str, params_list: list):
    """Bulk insert/update."""
    conn = None
    cursor = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.executemany(query, params_list)
        conn.commit()
        return cursor.rowcount
    except Error as e:
        if conn:
            conn.rollback()
        print(f"[DB ERROR] Bulk query failed: {e}")
        raise
    finally:
        if cursor:
            cursor.close()
        if conn and conn.is_connected():
            conn.close()
