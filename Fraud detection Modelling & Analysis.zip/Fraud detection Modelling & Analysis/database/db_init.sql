-- database/db_init.sql
-- Run: mysql -u root -p < database/db_init.sql

CREATE DATABASE IF NOT EXISTS fraud_detection_db;
USE fraud_detection_db;

-- ─────────────────────────────────────────────
-- Users table (for login authentication)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    user_id       INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role          ENUM('admin','analyst') DEFAULT 'analyst',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default admin user (password: #Hf1214158)
INSERT IGNORE INTO users (username, password_hash, role)
VALUES ('admin', 'pbkdf2:sha256:260000$adminhashedpassword', 'admin');

-- ─────────────────────────────────────────────
-- Transactions table
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id     VARCHAR(50) PRIMARY KEY,
    user_id            VARCHAR(50) NOT NULL,
    transaction_amount DECIMAL(12, 2) NOT NULL,
    transaction_time   DATETIME NOT NULL,
    location           VARCHAR(100),
    payment_method     ENUM('Card','UPI','Online') NOT NULL,
    transaction_status ENUM('Normal','Fraud') DEFAULT 'Normal',
    fraud_prediction   ENUM('Fraud','Not Fraud','Pending') DEFAULT 'Pending',
    fraud_probability  DECIMAL(5, 4) DEFAULT NULL,
    risk_level         ENUM('Low','Medium','High') DEFAULT 'Low',
    created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────────
-- Fraud alerts table
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fraud_alerts (
    alert_id       INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id VARCHAR(50) NOT NULL,
    alert_message  TEXT,
    alert_severity ENUM('Low','Medium','High','Critical') DEFAULT 'Medium',
    is_resolved    BOOLEAN DEFAULT FALSE,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id)
);

-- ─────────────────────────────────────────────
-- Prediction logs table
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS prediction_logs (
    log_id         INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id VARCHAR(50),
    model_used     VARCHAR(50),
    prediction     ENUM('Fraud','Not Fraud'),
    confidence     DECIMAL(5, 4),
    predicted_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────────
-- Sample seed data
-- ─────────────────────────────────────────────
INSERT IGNORE INTO transactions
    (transaction_id, user_id, transaction_amount, transaction_time, location, payment_method, transaction_status, fraud_prediction, fraud_probability, risk_level)
VALUES
    ('TXN001', 'USR101', 1200.50, '2024-01-10 10:30:00', 'Mumbai',    'Card',   'Normal', 'Not Fraud', 0.0500, 'Low'),
    ('TXN002', 'USR102', 85000.00,'2024-01-10 11:00:00', 'Delhi',     'Online', 'Fraud',  'Fraud',     0.9800, 'High'),
    ('TXN003', 'USR103', 500.00,  '2024-01-11 09:15:00', 'Bangalore', 'UPI',    'Normal', 'Not Fraud', 0.0300, 'Low'),
    ('TXN004', 'USR104', 45000.00,'2024-01-11 23:45:00', 'Chennai',   'Card',   'Fraud',  'Fraud',     0.8900, 'High'),
    ('TXN005', 'USR105', 2300.75, '2024-01-12 14:20:00', 'Pune',      'UPI',    'Normal', 'Not Fraud', 0.1200, 'Low'),
    ('TXN006', 'USR106', 15000.00,'2024-01-12 02:10:00', 'Hyderabad', 'Online', 'Fraud',  'Fraud',     0.7500, 'Medium'),
    ('TXN007', 'USR107', 350.00,  '2024-01-13 08:00:00', 'Kolkata',   'UPI',    'Normal', 'Not Fraud', 0.0200, 'Low'),
    ('TXN008', 'USR108', 99000.00,'2024-01-13 22:30:00', 'Mumbai',    'Card',   'Fraud',  'Fraud',     0.9500, 'High'),
    ('TXN009', 'USR109', 780.00,  '2024-01-14 12:00:00', 'Delhi',     'Online', 'Normal', 'Not Fraud', 0.0800, 'Low'),
    ('TXN010', 'USR110', 34000.00,'2024-01-14 01:55:00', 'Bangalore', 'Card',   'Fraud',  'Fraud',     0.8200, 'High'),
    ('TXN011', 'USR111', 890.25,  '2024-02-01 10:00:00', 'Pune',      'UPI',    'Normal', 'Not Fraud', 0.0400, 'Low'),
    ('TXN012', 'USR112', 67000.00,'2024-02-02 03:20:00', 'Chennai',   'Online', 'Fraud',  'Fraud',     0.9100, 'High'),
    ('TXN013', 'USR113', 1500.00, '2024-02-03 15:45:00', 'Hyderabad', 'Card',   'Normal', 'Not Fraud', 0.0600, 'Low'),
    ('TXN014', 'USR114', 28000.00,'2024-02-04 00:30:00', 'Kolkata',   'UPI',    'Fraud',  'Fraud',     0.7800, 'High'),
    ('TXN015', 'USR115', 430.00,  '2024-02-05 09:10:00', 'Mumbai',    'Online', 'Normal', 'Not Fraud', 0.0100, 'Low'),
    ('TXN016', 'USR116', 55000.00,'2024-02-06 22:00:00', 'Delhi',     'Card',   'Fraud',  'Fraud',     0.8700, 'High'),
    ('TXN017', 'USR117', 2100.00, '2024-03-01 11:30:00', 'Bangalore', 'UPI',    'Normal', 'Not Fraud', 0.0900, 'Low'),
    ('TXN018', 'USR118', 78000.00,'2024-03-02 04:15:00', 'Pune',      'Online', 'Fraud',  'Fraud',     0.9300, 'High'),
    ('TXN019', 'USR119', 660.00,  '2024-03-03 13:00:00', 'Chennai',   'Card',   'Normal', 'Not Fraud', 0.0350, 'Low'),
    ('TXN020', 'USR120', 41000.00,'2024-03-04 23:10:00', 'Hyderabad', 'UPI',    'Fraud',  'Fraud',     0.8500, 'High');
