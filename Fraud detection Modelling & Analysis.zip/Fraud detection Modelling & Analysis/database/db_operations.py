# database/db_operations.py
"""
All CRUD operations for the fraud_detection_db.
Each function is self-contained and reusable across routes.
"""

from database.db_config import execute_query, execute_many
from werkzeug.security import generate_password_hash, check_password_hash
import uuid
from datetime import datetime


# ─────────────────────────────────────────────
# AUTH OPERATIONS
# ─────────────────────────────────────────────

def get_user_by_username(username: str) -> dict | None:
    """Fetch user record by username."""
    rows = execute_query(
        "SELECT * FROM users WHERE username = %s LIMIT 1",
        (username,), fetch=True
    )
    return rows[0] if rows else None


def verify_user(username: str, password: str) -> dict | None:
    """Verify login credentials. Returns user dict or None."""
    user = get_user_by_username(username)
    if user and check_password_hash(user['password_hash'], password):
        return user
    return None


def create_user(username: str, password: str, role: str = 'analyst') -> int:
    """Insert a new user. Returns new user_id."""
    hashed = generate_password_hash(password)
    return execute_query(
        "INSERT INTO users (username, password_hash, role) VALUES (%s, %s, %s)",
        (username, hashed, role)
    )


# ─────────────────────────────────────────────
# TRANSACTION OPERATIONS
# ─────────────────────────────────────────────

def get_all_transactions(limit: int = 100, offset: int = 0) -> list:
    """Fetch paginated transactions, newest first."""
    return execute_query(
        """SELECT * FROM transactions
           ORDER BY transaction_time DESC
           LIMIT %s OFFSET %s""",
        (limit, offset), fetch=True
    )


def get_transaction_by_id(txn_id: str) -> dict | None:
    """Fetch single transaction."""
    rows = execute_query(
        "SELECT * FROM transactions WHERE transaction_id = %s",
        (txn_id,), fetch=True
    )
    return rows[0] if rows else None


def insert_transaction(data: dict) -> str:
    """
    Insert a new transaction.
    data keys: user_id, transaction_amount, transaction_time,
               location, payment_method, transaction_status
    Returns generated transaction_id.
    """
    txn_id = data.get('transaction_id') or f"TXN{uuid.uuid4().hex[:8].upper()}"
    execute_query(
        """INSERT INTO transactions
           (transaction_id, user_id, transaction_amount, transaction_time,
            location, payment_method, transaction_status)
           VALUES (%s, %s, %s, %s, %s, %s, %s)""",
        (
            txn_id,
            data['user_id'],
            data['transaction_amount'],
            data.get('transaction_time', datetime.now()),
            data.get('location', 'Unknown'),
            data['payment_method'],
            data.get('transaction_status', 'Normal'),
        )
    )
    return txn_id


def update_transaction(txn_id: str, data: dict) -> int:
    """Update mutable fields of a transaction."""
    return execute_query(
        """UPDATE transactions
           SET transaction_amount = %s,
               location           = %s,
               payment_method     = %s,
               transaction_status = %s
           WHERE transaction_id = %s""",
        (
            data['transaction_amount'],
            data['location'],
            data['payment_method'],
            data['transaction_status'],
            txn_id,
        )
    )


def delete_transaction(txn_id: str) -> int:
    """Delete a transaction record."""
    execute_query(
        "DELETE FROM fraud_alerts WHERE transaction_id = %s", (txn_id,)
    )
    return execute_query(
        "DELETE FROM transactions WHERE transaction_id = %s", (txn_id,)
    )


def save_prediction_result(txn_id: str, prediction: str,
                            probability: float, risk_level: str,
                            model_used: str = 'RandomForest') -> None:
    """Update transaction with ML prediction and log it."""
    execute_query(
        """UPDATE transactions
           SET fraud_prediction  = %s,
               fraud_probability = %s,
               risk_level        = %s
           WHERE transaction_id  = %s""",
        (prediction, probability, risk_level, txn_id)
    )
    execute_query(
        """INSERT INTO prediction_logs
           (transaction_id, model_used, prediction, confidence)
           VALUES (%s, %s, %s, %s)""",
        (txn_id, model_used, prediction, probability)
    )
    if prediction == 'Fraud':
        severity = 'High' if probability > 0.85 else ('Medium' if probability > 0.60 else 'Low')
        execute_query(
            """INSERT INTO fraud_alerts
               (transaction_id, alert_message, alert_severity)
               VALUES (%s, %s, %s)""",
            (txn_id,
             f"Fraudulent transaction detected with {probability*100:.1f}% confidence.",
             severity)
        )


# ─────────────────────────────────────────────
# ANALYTICS QUERIES
# ─────────────────────────────────────────────

def get_dashboard_stats() -> dict:
    """Summary counts for the dashboard."""
    total   = execute_query("SELECT COUNT(*) AS cnt FROM transactions", fetch=True)[0]['cnt']
    fraud   = execute_query("SELECT COUNT(*) AS cnt FROM transactions WHERE fraud_prediction='Fraud'", fetch=True)[0]['cnt']
    alerts  = execute_query("SELECT COUNT(*) AS cnt FROM fraud_alerts WHERE is_resolved=0", fetch=True)[0]['cnt']
    high    = execute_query("SELECT COUNT(*) AS cnt FROM transactions WHERE risk_level='High'", fetch=True)[0]['cnt']
    return {
        'total_transactions': total,
        'fraud_count':        fraud,
        'normal_count':       total - fraud,
        'open_alerts':        alerts,
        'high_risk_count':    high,
        'fraud_rate':         round((fraud / total * 100) if total else 0, 2),
    }


def get_fraud_by_payment_method() -> list:
    return execute_query(
        """SELECT payment_method,
                  COUNT(*) AS total,
                  SUM(fraud_prediction='Fraud') AS fraud_count
           FROM transactions
           GROUP BY payment_method""",
        fetch=True
    )


def get_monthly_fraud_trend() -> list:
    return execute_query(
        """SELECT DATE_FORMAT(transaction_time, '%Y-%m') AS month,
                  COUNT(*) AS total,
                  SUM(fraud_prediction='Fraud') AS fraud_count
           FROM transactions
           GROUP BY month
           ORDER BY month""",
        fetch=True
    )


def get_amount_distribution() -> list:
    return execute_query(
        """SELECT transaction_amount, fraud_prediction, transaction_time
           FROM transactions
           ORDER BY transaction_time""",
        fetch=True
    )


def get_recent_alerts(limit: int = 10) -> list:
    return execute_query(
        """SELECT a.*, t.transaction_amount, t.user_id, t.payment_method
           FROM fraud_alerts a
           JOIN transactions t ON a.transaction_id = t.transaction_id
           WHERE a.is_resolved = 0
           ORDER BY a.created_at DESC
           LIMIT %s""",
        (limit,), fetch=True
    )


def get_high_risk_users() -> list:
    return execute_query(
        """SELECT user_id,
                  COUNT(*) AS fraud_transactions,
                  SUM(transaction_amount) AS total_amount
           FROM transactions
           WHERE fraud_prediction = 'Fraud'
           GROUP BY user_id
           ORDER BY fraud_transactions DESC
           LIMIT 10""",
        fetch=True
    )