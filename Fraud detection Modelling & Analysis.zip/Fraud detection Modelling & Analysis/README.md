# Fraud Detection Analysis and Modelling
**Student:** Hibba Fathima H | **USN:** U19ON23S0139

## Project Structure
```
fraud_detection/
│
├── app/
│   ├── __init__.py              # Flask app factory
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── auth_routes.py       # Login/Logout
│   │   ├── dashboard_routes.py  # Dashboard
│   │   ├── prediction_routes.py # Fraud Prediction
│   │   ├── data_routes.py       # Data CRUD
│   │   └── report_routes.py     # Reports & Future Analysis
│   └── config.py                # App configuration
│
├── database/
│   ├── __init__.py
│   ├── db_config.py             # MySQL connection
│   ├── db_init.sql              # Schema & seed data
│   └── db_operations.py         # CRUD operations
│
├── ml_pipeline/
│   ├── __init__.py
│   ├── preprocessor.py          # Data preprocessing
│   ├── feature_engineering.py   # Feature extraction
│   ├── model_trainer.py         # Model training (LR, DT, RF, SVM)
│   ├── model_evaluator.py       # Metrics evaluation
│   └── predictor.py             # Prediction logic
│
├── data_visualization/
│   ├── __init__.py
│   └── charts.py                # All chart generators
│
├── models/                      # Saved ML models (.pkl)
│
├── utils/
│   ├── __init__.py
│   ├── helpers.py               # Utility functions
│   └── validators.py            # Input validation
│
├── static/
│   ├── css/style.css
│   └── js/main.js
│
├── templates/
│   ├── base.html
│   ├── login.html
│   ├── dashboard.html
│   ├── data_management.html
│   ├── prediction.html
│   ├── output.html
│   └── reports.html
│
├── train_model.py               # Standalone model training script
├── requirements.txt
└── run.py                       # App entry point
```

## Setup Instructions
1. `pip install -r requirements.txt`
2. Configure MySQL in `app/config.py`

Get-Content database\db_init.sql | & "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p

3. Run `mysql -u root -p < database/db_init.sql`
4. Run `python train_model.py` to train ML model
5. Run `python run.py` to start the app

## Flow
Login → Dashboard → Fraud Detection / Data Management → Output (new tab)



final

1. pip list
2. "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p
3. python train_model.py
4. python run.py
