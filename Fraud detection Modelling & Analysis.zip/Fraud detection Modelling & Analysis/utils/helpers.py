# utils/helpers.py
"""General-purpose helper utilities."""

from datetime import datetime
import uuid


def generate_transaction_id() -> str:
    """Generate a unique transaction ID."""
    return f"TXN{uuid.uuid4().hex[:8].upper()}"


def format_currency(amount: float) -> str:
    """Format a number as Indian Rupees."""
    return f"₹{amount:,.2f}"


def format_datetime(dt) -> str:
    """Return a human-readable datetime string."""
    if isinstance(dt, str):
        try:
            dt = datetime.strptime(dt, '%Y-%m-%d %H:%M:%S')
        except Exception:
            return dt
    return dt.strftime('%d %b %Y, %I:%M %p') if dt else 'N/A'


def paginate(items: list, page: int, per_page: int = 20) -> dict:
    """Simple in-memory pagination."""
    total   = len(items)
    start   = (page - 1) * per_page
    end     = start + per_page
    return {
        'items':       items[start:end],
        'total':       total,
        'page':        page,
        'per_page':    per_page,
        'total_pages': (total + per_page - 1) // per_page,
    }


def flash_category(success: bool) -> str:
    return 'success' if success else 'danger'


# utils/validators.py
"""Input validation functions for form data."""

def validate_transaction_form(form_data: dict) -> tuple[bool, list[str]]:
    """Validate transaction form fields. Returns (is_valid, errors)."""
    errors = []
    required = ['user_id', 'transaction_amount', 'payment_method']
    for field in required:
        if not form_data.get(field):
            errors.append(f"'{field}' is required.")

    try:
        amount = float(form_data.get('transaction_amount', 0))
        if amount <= 0:
            errors.append("Transaction amount must be positive.")
    except (ValueError, TypeError):
        errors.append("Transaction amount must be a valid number.")

    valid_methods = {'Card', 'UPI', 'Online'}
    if form_data.get('payment_method') not in valid_methods:
        errors.append(f"Payment method must be one of: {', '.join(valid_methods)}.")

    return len(errors) == 0, errors


def validate_login_form(form_data: dict) -> tuple[bool, list[str]]:
    errors = []
    if not form_data.get('username'):
        errors.append("Username is required.")
    if not form_data.get('password'):
        errors.append("Password is required.")
    return len(errors) == 0, errors


def validate_signup_form(form_data: dict) -> tuple[bool, list[str]]:
    """Validate signup form fields. Returns (is_valid, errors)."""
    import re
    errors = []

    username = (form_data.get('username') or '').strip()
    password = form_data.get('password') or ''
    confirm  = form_data.get('confirm_password') or ''
    role     = form_data.get('role') or ''

    if not username:
        errors.append("Username is required.")
    elif len(username) < 3:
        errors.append("Username must be at least 3 characters.")
    elif len(username) > 50:
        errors.append("Username must be 50 characters or fewer.")
    elif not re.match(r'^[a-zA-Z0-9_]+$', username):
        errors.append("Username may only contain letters, numbers, and underscores.")

    if not password:
        errors.append("Password is required.")
    elif len(password) < 6:
        errors.append("Password must be at least 6 characters.")

    if not confirm:
        errors.append("Please confirm your password.")
    elif password and password != confirm:
        errors.append("Passwords do not match.")

    if role not in ('admin', 'analyst'):
        errors.append("Role must be 'admin' or 'analyst'.")

    return len(errors) == 0, errors
