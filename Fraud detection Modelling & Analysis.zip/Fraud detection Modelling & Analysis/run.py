#!/usr/bin/env python3
"""
run.py – Application entry point.

Usage:
    python run.py
    python run.py --prod     # production mode
"""

import os
import sys
import argparse
from app import create_app
from ml_pipeline.predictor import predictor

def parse_args():
    parser = argparse.ArgumentParser(description='Fraud Detection System')
    parser.add_argument('--prod', action='store_true', help='Run in production mode')
    parser.add_argument('--host', default='127.0.0.1', help='Host (default: 127.0.0.1)')
    parser.add_argument('--port', type=int, default=5000, help='Port (default: 5000)')
    return parser.parse_args()


def main():
    args = parse_args()
    config_name = 'production' if args.prod else 'development'
    app = create_app(config_name)

    # Pre-load ML model if it exists
    model_path  = app.config['MODEL_PATH']
    scaler_path = app.config['SCALER_PATH']
    if os.path.exists(model_path) and os.path.exists(scaler_path):
        with app.app_context():
            predictor.load(model_path, scaler_path)
        print(f"[Startup] ML model loaded: {model_path}")
    else:
        print(f"[Startup] ⚠️  No trained model found at {model_path}")
        print("           Run  python train_model.py  before making predictions.")

    print(f"\n{'='*55}")
    print(f"  🛡️  Fraud Detection System")
    print(f"  Mode  : {'Production' if args.prod else 'Development'}")
    print(f"  URL   : http://{args.host}:{args.port}")
    print(f"  Login : admin / admin123")
    print(f"{'='*55}\n")

    app.run(
        host=args.host,
        port=args.port,
        debug=not args.prod,
        use_reloader=False,   # disable reloader to avoid double model-load
    )


if __name__ == '__main__':
    main()
