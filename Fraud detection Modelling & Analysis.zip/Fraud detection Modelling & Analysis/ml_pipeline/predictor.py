# ml_pipeline/predictor.py
"""
Prediction logic: load model + preprocessor, predict single transactions.
"""

import joblib
import numpy as np
from ml_pipeline.preprocessor import FraudPreprocessor
from ml_pipeline.feature_engineering import FeatureEngineer


def _get_risk_level(probability: float) -> str:
    if probability >= 0.80:
        return 'High'
    elif probability >= 0.50:
        return 'Medium'
    return 'Low'


class FraudPredictor:
    """Singleton-style loader for inference."""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._loaded = False
        return cls._instance

    def load(self, model_path: str, scaler_path: str) -> None:
        """Load model and preprocessor from disk."""
        bundle = joblib.load(model_path)
        self.model = bundle['model']
        self.model_name = bundle['name']
        self.preprocessor = FraudPreprocessor.load(scaler_path)
        self.feature_engineer = FeatureEngineer()
        self._loaded = True
        print(f"[Predictor] Loaded model: {self.model_name}")

    def predict(self, transaction: dict) -> dict:
        """
        Predict fraud for a single transaction dict.
        Returns: { prediction, probability, risk_level, model_name }
        """
        if not self._loaded:
            raise RuntimeError("Predictor not loaded. Call load() first.")

        import pandas as pd
        df = pd.DataFrame([transaction])
        df = self.feature_engineer.transform(df)
        X = self.preprocessor.transform(df)

        prob = self.model.predict_proba(X)[0][1]
        label = 'Fraud' if prob >= 0.5 else 'Not Fraud'
        risk = _get_risk_level(prob)

        return {
            'prediction':   label,
            'probability':  round(float(prob), 4),
            'risk_level':   risk,
            'model_name':   self.model_name,
        }

    @property
    def is_loaded(self) -> bool:
        return self._loaded


# Global predictor instance
predictor = FraudPredictor()
