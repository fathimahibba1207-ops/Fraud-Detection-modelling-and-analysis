# ml_pipeline/model_trainer.py
"""
Train multiple ML models (LR, DT, RF, SVM) and select the best.
"""

import numpy as np
import joblib
import os
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC


MODELS = {
    'LogisticRegression': LogisticRegression(max_iter=1000, random_state=42),
    'DecisionTree':       DecisionTreeClassifier(max_depth=10, random_state=42),
    'RandomForest':       RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1),
    'SVM':                SVC(kernel='rbf', probability=True, random_state=42),
}


class ModelTrainer:
    """Train and persist fraud detection models."""

    def __init__(self, model_dir: str = 'models'):
        self.model_dir = model_dir
        self.trained_models: dict = {}
        self.best_model_name: str = ''
        self.best_model = None
        os.makedirs(model_dir, exist_ok=True)

    def train_all(self, X_train: np.ndarray, y_train: np.ndarray) -> dict:
        """Train all models and return them keyed by name."""
        print("[Trainer] Training all models...")
        for name, model in MODELS.items():
            print(f"  → {name} ...", end=' ')
            model.fit(X_train, y_train)
            self.trained_models[name] = model
            print("done")
        return self.trained_models

    def select_best(self, X_val: np.ndarray, y_val: np.ndarray) -> str:
        """Select best model by F1-score on validation set."""
        from sklearn.metrics import f1_score
        best_f1, best_name = -1, ''
        for name, model in self.trained_models.items():
            preds = model.predict(X_val)
            f1 = f1_score(y_val, preds, zero_division=0)
            print(f"  [{name}] F1 = {f1:.4f}")
            if f1 > best_f1:
                best_f1, best_name = f1, name
        self.best_model_name = best_name
        self.best_model = self.trained_models[best_name]
        print(f"[Trainer] Best model: {best_name} (F1={best_f1:.4f})")
        return best_name

    def save_best(self, path: str) -> None:
        """Persist best model to disk."""
        if self.best_model is None:
            raise ValueError("No best model selected. Call select_best() first.")
        joblib.dump({'model': self.best_model, 'name': self.best_model_name}, path)
        print(f"[Trainer] Best model saved → {path}")

    def save_all(self) -> None:
        """Save every trained model individually."""
        for name, model in self.trained_models.items():
            path = os.path.join(self.model_dir, f"{name.lower()}.pkl")
            joblib.dump(model, path)
        print(f"[Trainer] All models saved to {self.model_dir}/")

    @staticmethod
    def load_model(path: str):
        """Load a saved model bundle."""
        data = joblib.load(path)
        return data['model'], data['name']
