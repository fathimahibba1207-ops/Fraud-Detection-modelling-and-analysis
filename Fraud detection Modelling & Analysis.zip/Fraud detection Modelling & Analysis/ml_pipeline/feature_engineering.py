# ml_pipeline/feature_engineering.py
"""
Feature engineering for fraud detection.
Creates derived features that improve model performance.
"""

import pandas as pd
import numpy as np


class FeatureEngineer:
    """Generate domain-specific features from raw transaction data."""

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        df = self._time_features(df)
        df = self._amount_features(df)
        df = self._behavioral_features(df)
        return df

    # ── Time-based features ──────────────────────────────────

    def _time_features(self, df: pd.DataFrame) -> pd.DataFrame:
        if 'transaction_time' not in df.columns:
            return df
        dt = pd.to_datetime(df['transaction_time'], errors='coerce')
        df['hour']            = dt.dt.hour
        df['day_of_week']     = dt.dt.dayofweek          # 0=Mon, 6=Sun
        df['is_weekend']      = (df['day_of_week'] >= 5).astype(int)
        df['is_night']        = ((df['hour'] >= 22) | (df['hour'] <= 5)).astype(int)
        df['month']           = dt.dt.month
        df['day_of_month']    = dt.dt.day
        # High-risk hour windows (known fraud spikes)
        df['is_high_risk_hour'] = df['hour'].isin([0, 1, 2, 3, 23]).astype(int)
        return df

    # ── Amount-based features ────────────────────────────────

    def _amount_features(self, df: pd.DataFrame) -> pd.DataFrame:
        if 'transaction_amount' not in df.columns:
            return df
        amt = df['transaction_amount']
        df['log_amount']      = np.log1p(amt)
        df['is_large_txn']    = (amt > 50000).astype(int)
        df['is_round_amount'] = (amt % 1000 == 0).astype(int)
        # Bin into amount categories
        df['amount_bin'] = pd.cut(
            amt,
            bins=[0, 500, 2000, 10000, 50000, np.inf],
            labels=[0, 1, 2, 3, 4]
        ).astype(int)
        return df

    # ── Behavioral / contextual features ────────────────────

    def _behavioral_features(self, df: pd.DataFrame) -> pd.DataFrame:
        # Payment method risk scores
        method_risk = {'Card': 2, 'Online': 3, 'UPI': 1}
        if 'payment_method' in df.columns:
            df['payment_risk_score'] = df['payment_method'].map(method_risk).fillna(1)
        # Compound risk: large + night + high-risk-hour
        if all(c in df.columns for c in ['is_large_txn', 'is_night', 'is_high_risk_hour']):
            df['compound_risk'] = (
                df['is_large_txn'] + df['is_night'] + df['is_high_risk_hour']
            )
        return df
