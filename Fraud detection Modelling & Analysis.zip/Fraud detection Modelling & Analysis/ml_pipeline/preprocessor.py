# ml_pipeline/preprocessor.py
"""
Data preprocessing pipeline for fraud detection.
Handles missing values, encoding, and scaling.
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
import joblib
import os


class FraudPreprocessor:
    """Preprocessing pipeline: clean → encode → scale → balance."""

    def __init__(self):
        self.scaler = StandardScaler()
        self.label_encoders: dict[str, LabelEncoder] = {}
        self.feature_columns: list[str] = []
        self.is_fitted = False

    # ── Public API ──────────────────────────────────────────

    def fit_transform(self, df: pd.DataFrame, target_col: str = 'is_fraud'):
        """Full pipeline for training data."""
        df = self._clean(df)
        df = self._encode(df, fit=True)
        X, y = self._split_features(df, target_col)
        X_scaled = self._scale(X, fit=True)
        X_balanced, y_balanced = self._balance(X_scaled, y)
        self.is_fitted = True
        return X_balanced, y_balanced

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        """Transform inference data (must call fit_transform first)."""
        if not self.is_fitted:
            raise RuntimeError("Preprocessor is not fitted. Call fit_transform() first.")
        df = self._clean(df)
        df = self._encode(df, fit=False)
        X = df[self.feature_columns]
        return self._scale(X, fit=False)

    def transform_single(self, record: dict) -> np.ndarray:
        """Transform a single transaction dict for prediction."""
        df = pd.DataFrame([record])
        return self.transform(df)

    # ── Private helpers ──────────────────────────────────────

    def _clean(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        # Fill numeric NaNs with median
        num_cols = df.select_dtypes(include=[np.number]).columns
        for col in num_cols:
            df[col].fillna(df[col].median(), inplace=True)
        # Fill categorical NaNs with mode
        cat_cols = df.select_dtypes(include=['object']).columns
        for col in cat_cols:
            df[col].fillna(df[col].mode()[0] if not df[col].mode().empty else 'Unknown', inplace=True)
        # Remove obvious duplicates
        df.drop_duplicates(inplace=True)
        return df

    def _encode(self, df: pd.DataFrame, fit: bool) -> pd.DataFrame:
        df = df.copy()
        cat_cols = df.select_dtypes(include=['object']).columns.tolist()
        # Remove target if present
        cat_cols = [c for c in cat_cols if c not in ('is_fraud', 'transaction_status', 'fraud_prediction')]
        for col in cat_cols:
            if fit:
                le = LabelEncoder()
                df[col] = le.fit_transform(df[col].astype(str))
                self.label_encoders[col] = le
            else:
                if col in self.label_encoders:
                    le = self.label_encoders[col]
                    df[col] = df[col].astype(str).apply(
                        lambda x: le.transform([x])[0] if x in le.classes_ else -1
                    )
        return df

    def _split_features(self, df: pd.DataFrame, target_col: str):
        drop_cols = [target_col, 'transaction_id', 'transaction_time', 'created_at', 'updated_at',
                     'transaction_status', 'fraud_prediction', 'user_id']
        drop_cols = [c for c in drop_cols if c in df.columns]
        self.feature_columns = [c for c in df.columns if c not in drop_cols]
        X = df[self.feature_columns]
        y = df[target_col] if target_col in df.columns else None
        return X, y

    def _scale(self, X: pd.DataFrame, fit: bool) -> np.ndarray:
        if fit:
            return self.scaler.fit_transform(X)
        return self.scaler.transform(X)

    def _balance(self, X: np.ndarray, y: pd.Series):
        """SMOTE to handle class imbalance."""
        try:
            smote = SMOTE(random_state=42)
            return smote.fit_resample(X, y)
        except Exception as e:
            print(f"[SMOTE Warning] {e} – returning unbalanced data.")
            return X, y

    # ── Persistence ──────────────────────────────────────────

    def save(self, scaler_path: str, encoders_path: str):
        os.makedirs(os.path.dirname(scaler_path), exist_ok=True)
        joblib.dump({'scaler': self.scaler,
                     'encoders': self.label_encoders,
                     'features': self.feature_columns}, scaler_path)

    @classmethod
    def load(cls, scaler_path: str) -> 'FraudPreprocessor':
        data = joblib.load(scaler_path)
        obj = cls()
        obj.scaler = data['scaler']
        obj.label_encoders = data['encoders']
        obj.feature_columns = data['features']
        obj.is_fitted = True
        return obj
