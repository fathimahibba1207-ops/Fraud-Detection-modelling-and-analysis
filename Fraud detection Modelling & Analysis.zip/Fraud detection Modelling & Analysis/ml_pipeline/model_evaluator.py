# ml_pipeline/model_evaluator.py
"""
Evaluate trained models and generate performance reports.
"""

import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, confusion_matrix,
    classification_report
)


class ModelEvaluator:
    """Compute and format all evaluation metrics."""

    def evaluate(self, model, X_test: np.ndarray, y_test: np.ndarray,
                 model_name: str = 'Model') -> dict:
        """Return a full metrics dict for a given model."""
        y_pred = model.predict(X_test)
        y_prob = (model.predict_proba(X_test)[:, 1]
                  if hasattr(model, 'predict_proba') else None)

        cm = confusion_matrix(y_test, y_pred)
        tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)

        metrics = {
            'model_name':  model_name,
            'accuracy':    round(accuracy_score(y_test, y_pred) * 100, 2),
            'precision':   round(precision_score(y_test, y_pred, zero_division=0) * 100, 2),
            'recall':      round(recall_score(y_test, y_pred, zero_division=0) * 100, 2),
            'f1_score':    round(f1_score(y_test, y_pred, zero_division=0) * 100, 2),
            'roc_auc':     round(roc_auc_score(y_test, y_prob) * 100, 2) if y_prob is not None else None,
            'confusion_matrix': {
                'tn': int(tn), 'fp': int(fp),
                'fn': int(fn), 'tp': int(tp),
            },
            'classification_report': classification_report(y_test, y_pred, zero_division=0),
        }
        return metrics

    def compare_models(self, models: dict, X_test: np.ndarray,
                       y_test: np.ndarray) -> list[dict]:
        """Evaluate multiple models and sort by F1 descending."""
        results = [self.evaluate(m, X_test, y_test, name)
                   for name, m in models.items()]
        return sorted(results, key=lambda r: r['f1_score'], reverse=True)

    def print_report(self, metrics: dict) -> None:
        print(f"\n{'='*50}")
        print(f"Model: {metrics['model_name']}")
        print(f"  Accuracy  : {metrics['accuracy']}%")
        print(f"  Precision : {metrics['precision']}%")
        print(f"  Recall    : {metrics['recall']}%")
        print(f"  F1-Score  : {metrics['f1_score']}%")
        if metrics['roc_auc']:
            print(f"  ROC-AUC   : {metrics['roc_auc']}%")
        cm = metrics['confusion_matrix']
        print(f"  Confusion Matrix: TP={cm['tp']} FP={cm['fp']} TN={cm['tn']} FN={cm['fn']}")
        print(f"{'='*50}\n")
