# data_visualization/charts.py
"""
All chart generators using Matplotlib + Seaborn.
Each function saves a PNG to static/charts/ and returns the filename.
"""

import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import pandas as pd
import numpy as np

CHART_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'charts')
os.makedirs(CHART_DIR, exist_ok=True)

# Color palette
COLORS = {
    'fraud':   '#e74c3c',
    'normal':  '#2ecc71',
    'accent':  '#3498db',
    'warning': '#f39c12',
    'dark':    '#2c3e50',
    'light':   '#ecf0f1',
}

plt.rcParams.update({
    'figure.facecolor': 'white',
    'axes.facecolor':   '#f8f9fa',
    'axes.grid':        True,
    'grid.alpha':       0.3,
    'font.family':      'sans-serif',
})


def _save(fig, filename: str) -> str:
    path = os.path.join(CHART_DIR, filename)
    fig.savefig(path, dpi=120, bbox_inches='tight')
    plt.close(fig)
    return filename


# ── 1. Bar Chart: Fraud vs Normal ─────────────────────────────────────────────

def bar_fraud_vs_normal(fraud_count: int, normal_count: int) -> str:
    fig, ax = plt.subplots(figsize=(7, 5))
    categories = ['Normal Transactions', 'Fraudulent Transactions']
    counts     = [normal_count, fraud_count]
    bars = ax.bar(categories, counts,
                  color=[COLORS['normal'], COLORS['fraud']],
                  width=0.45, edgecolor='white', linewidth=1.5)
    for bar, val in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + max(counts) * 0.02,
                f'{val:,}', ha='center', va='bottom',
                fontsize=13, fontweight='bold')
    ax.set_title('Fraud vs Normal Transactions', fontsize=15, fontweight='bold',
                 color=COLORS['dark'], pad=15)
    ax.set_ylabel('Count', fontsize=12)
    ax.set_ylim(0, max(counts) * 1.15)
    ax.tick_params(axis='both', labelsize=11)
    return _save(fig, 'bar_fraud_normal.png')


# ── 2. Pie Chart: Fraud Distribution ──────────────────────────────────────────

def pie_fraud_distribution(fraud_count: int, normal_count: int) -> str:
    fig, ax = plt.subplots(figsize=(6, 6))
    sizes  = [normal_count, fraud_count]
    labels = [f'Normal\n({normal_count:,})', f'Fraud\n({fraud_count:,})']
    colors = [COLORS['normal'], COLORS['fraud']]
    wedges, texts, autotexts = ax.pie(
        sizes, labels=labels, colors=colors,
        autopct='%1.1f%%', startangle=140,
        pctdistance=0.75,
        wedgeprops={'edgecolor': 'white', 'linewidth': 2},
        explode=(0, 0.08),
    )
    for at in autotexts:
        at.set_fontsize(12)
        at.set_fontweight('bold')
        at.set_color('white')
    ax.set_title('Fraud Distribution (%)', fontsize=15, fontweight='bold',
                 color=COLORS['dark'], pad=15)
    return _save(fig, 'pie_fraud_distribution.png')


# ── 3. Histogram: Transaction Amount Distribution ─────────────────────────────

def histogram_amount_distribution(transactions: list) -> str:
    df = pd.DataFrame(transactions)
    if df.empty or 'transaction_amount' not in df.columns:
        return ''
    fig, ax = plt.subplots(figsize=(9, 5))
    for label, color in [('Not Fraud', COLORS['normal']), ('Fraud', COLORS['fraud'])]:
        subset = df[df['fraud_prediction'] == label]['transaction_amount']
        if not subset.empty:
            ax.hist(subset, bins=30, alpha=0.7, color=color, label=label, edgecolor='white')
    ax.set_title('Transaction Amount Distribution', fontsize=15, fontweight='bold',
                 color=COLORS['dark'], pad=15)
    ax.set_xlabel('Transaction Amount (₹)', fontsize=12)
    ax.set_ylabel('Frequency', fontsize=12)
    ax.legend(fontsize=11)
    ax.tick_params(axis='both', labelsize=10)
    return _save(fig, 'histogram_amount.png')


# ── 4. Scatter Plot: Amount vs Time ───────────────────────────────────────────

def scatter_amount_vs_time(transactions: list) -> str:
    df = pd.DataFrame(transactions)
    if df.empty or 'transaction_amount' not in df.columns:
        return ''
    if 'transaction_time' not in df.columns:
        # Fallback: plot amount distribution without time axis
        return histogram_amount_distribution(transactions)
    df['transaction_time'] = pd.to_datetime(df['transaction_time'], errors='coerce')
    df = df.dropna(subset=['transaction_time'])
    if df.empty:
        return ''
    df['hour'] = df['transaction_time'].dt.hour
    fig, ax = plt.subplots(figsize=(10, 5))
    for label, color in [('Not Fraud', COLORS['normal']), ('Fraud', COLORS['fraud'])]:
        subset = df[df['fraud_prediction'] == label]
        ax.scatter(subset['hour'], subset['transaction_amount'],
                   c=color, label=label, alpha=0.6, s=40, edgecolors='none')
    ax.set_title('Transaction Amount vs Hour of Day', fontsize=15, fontweight='bold',
                 color=COLORS['dark'], pad=15)
    ax.set_xlabel('Hour of Day (0–23)', fontsize=12)
    ax.set_ylabel('Transaction Amount (₹)', fontsize=12)
    ax.set_xticks(range(0, 24))
    ax.legend(fontsize=11)
    return _save(fig, 'scatter_amount_time.png')


# ── 5. Heatmap: Payment Method × Risk Level ───────────────────────────────────

def heatmap_fraud_patterns(transactions: list) -> str:
    df = pd.DataFrame(transactions)
    if df.empty or 'payment_method' not in df.columns:
        return ''
    pivot = pd.crosstab(df['payment_method'], df.get('risk_level', df['fraud_prediction']))
    fig, ax = plt.subplots(figsize=(8, 4))
    sns.heatmap(pivot, annot=True, fmt='d', cmap='YlOrRd',
                linewidths=0.5, ax=ax, cbar_kws={'label': 'Count'})
    ax.set_title('Fraud Pattern Heatmap (Payment Method × Risk)', fontsize=14,
                 fontweight='bold', color=COLORS['dark'], pad=15)
    ax.set_xlabel('Risk Level', fontsize=11)
    ax.set_ylabel('Payment Method', fontsize=11)
    return _save(fig, 'heatmap_patterns.png')


# ── 6. Monthly Trend Line ─────────────────────────────────────────────────────

def line_monthly_trend(monthly_data: list) -> str:
    if not monthly_data:
        return ''
    df = pd.DataFrame(monthly_data)
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(df['month'], df['total'],      marker='o', color=COLORS['accent'],
            label='Total', linewidth=2)
    ax.plot(df['month'], df['fraud_count'], marker='s', color=COLORS['fraud'],
            label='Fraud', linewidth=2)
    ax.fill_between(df['month'], df['fraud_count'], alpha=0.15, color=COLORS['fraud'])
    ax.set_title('Monthly Transaction & Fraud Trend', fontsize=15, fontweight='bold',
                 color=COLORS['dark'], pad=15)
    ax.set_xlabel('Month', fontsize=12)
    ax.set_ylabel('Count', fontsize=12)
    ax.legend(fontsize=11)
    plt.xticks(rotation=45)
    plt.tight_layout()
    return _save(fig, 'line_monthly_trend.png')


# ── 7. Bar: Fraud by Payment Method ──────────────────────────────────────────

def bar_fraud_by_payment(payment_data: list) -> str:
    if not payment_data:
        return ''
    df = pd.DataFrame(payment_data)
    fig, ax = plt.subplots(figsize=(7, 5))
    x = np.arange(len(df))
    w = 0.35
    ax.bar(x - w/2, df['total'],       w, label='Total',        color=COLORS['accent'],  alpha=0.85)
    ax.bar(x + w/2, df['fraud_count'], w, label='Fraud',         color=COLORS['fraud'],   alpha=0.85)
    ax.set_xticks(x)
    ax.set_xticklabels(df['payment_method'], fontsize=12)
    ax.set_title('Fraud by Payment Method', fontsize=15, fontweight='bold',
                 color=COLORS['dark'], pad=15)
    ax.set_ylabel('Count', fontsize=12)
    ax.legend(fontsize=11)
    return _save(fig, 'bar_payment_method.png')


# ── 8. Confusion Matrix Heatmap ───────────────────────────────────────────────

def heatmap_confusion_matrix(tn: int, fp: int, fn: int, tp: int) -> str:
    cm = np.array([[tn, fp], [fn, tp]])
    fig, ax = plt.subplots(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=['Predicted Normal', 'Predicted Fraud'],
                yticklabels=['Actual Normal', 'Actual Fraud'],
                ax=ax, linewidths=0.5)
    ax.set_title('Confusion Matrix', fontsize=14, fontweight='bold',
                 color=COLORS['dark'], pad=15)
    return _save(fig, 'heatmap_confusion_matrix.png')