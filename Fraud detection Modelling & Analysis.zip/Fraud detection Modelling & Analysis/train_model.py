#!/usr/bin/env python3
"""
train_model.py
──────────────
Standalone script to train the fraud detection ML models.

Run: python train_model.py

This script:
1. Generates synthetic Indian transaction data (or loads your CSV).
2. Applies feature engineering.
3. Preprocesses (encode + scale + SMOTE).
4. Trains LR, DT, RF, SVM.
5. Evaluates all models and picks the best.
6. Saves best model to models/fraud_model.pkl
7. Saves preprocessor to models/scaler.pkl
"""

import os
import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ml_pipeline.feature_engineering import FeatureEngineer
from ml_pipeline.preprocessor import FraudPreprocessor
from ml_pipeline.model_trainer import ModelTrainer
from ml_pipeline.model_evaluator import ModelEvaluator


MODEL_DIR   = os.path.join(os.path.dirname(__file__), 'models')
MODEL_PATH  = os.path.join(MODEL_DIR, 'fraud_model.pkl')
SCALER_PATH = os.path.join(MODEL_DIR, 'scaler.pkl')
DATA_PATH   = os.path.join(os.path.dirname(__file__), 'data', 'transactions.csv')


# ── 1. Data Loading / Generation ─────────────────────────────────────────────

def generate_synthetic_data(n: int = 5000) -> pd.DataFrame:
    """
    Generate a realistic synthetic transaction dataset.
    Class imbalance: ~20% fraud (matches real-world fraud rates).
    """
    np.random.seed(42)
    n_fraud  = int(n * 0.20)
    n_normal = n - n_fraud

    def make_records(count, is_fraud):
        hours     = (np.random.choice([0,1,2,3,22,23], count)
                     if is_fraud else np.random.randint(6, 22, count))
        amounts   = (np.random.exponential(40000, count).clip(5000, 120000)
                     if is_fraud else np.random.exponential(2000, count).clip(50, 25000))
        methods   = np.random.choice(
            ['Card', 'UPI', 'Online'],
            count,
            p=[0.5, 0.2, 0.3] if is_fraud else [0.3, 0.5, 0.2]
        )
        locations = np.random.choice(
            ['Mumbai','Delhi','Bangalore','Chennai','Hyderabad','Pune','Kolkata','Jaipur'],
            count
        )
        dates = pd.date_range('2023-01-01', periods=count, freq='h') + \
                pd.to_timedelta(np.random.randint(0, 8760*2, count), unit='h')
        return pd.DataFrame({
            'transaction_amount': amounts.round(2),
            'transaction_time':   dates[:count],
            'location':           locations,
            'payment_method':     methods,
            'is_fraud':           int(is_fraud),
            'hour':               hours
        })

    df = pd.concat([make_records(n_normal, 0), make_records(n_fraud, 1)], ignore_index=True)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    print(f"[Data] Generated {len(df)} records  (fraud={n_fraud}, normal={n_normal})")
    return df


def load_data() -> pd.DataFrame:
    if os.path.exists(DATA_PATH):
        print(f"[Data] Loading from {DATA_PATH}")
        df = pd.read_csv(DATA_PATH, parse_dates=['transaction_time'])
        if 'is_fraud' not in df.columns and 'transaction_status' in df.columns:
            df['is_fraud'] = (df['transaction_status'] == 'Fraud').astype(int)
        return df
    print("[Data] No CSV found – generating synthetic data.")
    return generate_synthetic_data(n=6000)


# ── 2. Helper: drop non-feature columns ──────────────────────────────────────

def drop_meta_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Remove columns that are not model features."""
    drop_cols = [
        'transaction_id', 'created_at', 'updated_at',
        'transaction_status', 'fraud_prediction', 'user_id'
    ]
    return df.drop(columns=[c for c in drop_cols if c in df.columns])


# ── 3. Helper: encode categoricals using fitted label encoders ────────────────

def encode_with_fitted(df: pd.DataFrame, preprocessor: FraudPreprocessor) -> pd.DataFrame:
    """
    Apply the label encoders fitted during training to a new dataframe.
    Unseen labels are mapped to -1 to avoid crashes.
    """
    df = df.copy()
    for col, le in preprocessor.label_encoders.items():
        if col in df.columns:
            df[col] = df[col].map(
                lambda x, _le=le: int(_le.transform([x])[0]) if x in _le.classes_ else -1
            )
    return df


# ── 4. Main Training Pipeline ─────────────────────────────────────────────────

def main():
    os.makedirs(MODEL_DIR, exist_ok=True)

    # ── Load data ──────────────────────────────────────────────────────────────
    df = load_data()
    print(f"[Data] Shape: {df.shape}  |  Fraud rate: {df['is_fraud'].mean()*100:.1f}%")

    # ── Feature engineering ───────────────────────────────────────────────────
    fe = FeatureEngineer()
    df = fe.transform(df)
    print(f"[FE]   Features after engineering: {df.shape[1]}")

    # ── Train / val / test split ──────────────────────────────────────────────
    train_df, test_df = train_test_split(
        df, test_size=0.2, random_state=42, stratify=df['is_fraud']
    )
    train_df, val_df = train_test_split(
        train_df, test_size=0.15, random_state=42, stratify=train_df['is_fraud']
    )
    print(f"[Split] Train={len(train_df)}  Val={len(val_df)}  Test={len(test_df)}")

    # ── Preprocessing (fit only on train) ─────────────────────────────────────
    preprocessor = FraudPreprocessor()
    X_train, y_train = preprocessor.fit_transform(train_df, target_col='is_fraud')

    # ── Transform val set ─────────────────────────────────────────────────────
    val_clean   = drop_meta_columns(val_df.copy())
    val_encoded = encode_with_fitted(val_clean, preprocessor)
    X_val       = preprocessor.scaler.transform(
        val_encoded[preprocessor.feature_columns].fillna(0)
    )
    y_val = val_df['is_fraud'].values

    # ── Transform test set ────────────────────────────────────────────────────
    test_clean   = drop_meta_columns(test_df.copy())
    test_encoded = encode_with_fitted(test_clean, preprocessor)
    X_test       = preprocessor.scaler.transform(
        test_encoded[preprocessor.feature_columns].fillna(0)
    )
    y_test = test_df['is_fraud'].values

    print(f"[Prep] X_train={X_train.shape}  X_val={X_val.shape}  X_test={X_test.shape}")

    # ── Train all models ──────────────────────────────────────────────────────
    trainer = ModelTrainer(model_dir=MODEL_DIR)
    trainer.train_all(X_train, y_train)

    # ── Select best by validation F1 ──────────────────────────────────────────
    print("\n[Eval] Validation scores:")
    best_name = trainer.select_best(X_val, y_val)

    # ── Full evaluation on test set ───────────────────────────────────────────
    evaluator = ModelEvaluator()
    print("\n[Eval] Test set results (all models):")
    results = evaluator.compare_models(trainer.trained_models, X_test, y_test)
    for r in results:
        evaluator.print_report(r)

    # ── Save best model + preprocessor ───────────────────────────────────────
    trainer.save_best(MODEL_PATH)
    preprocessor.save(SCALER_PATH, SCALER_PATH)
    trainer.save_all()

    print(f"\n✅ Training complete!")
    print(f"   Best model : {best_name}")
    print(f"   Model path : {MODEL_PATH}")
    print(f"   Scaler path: {SCALER_PATH}")


if __name__ == '__main__':
    main()