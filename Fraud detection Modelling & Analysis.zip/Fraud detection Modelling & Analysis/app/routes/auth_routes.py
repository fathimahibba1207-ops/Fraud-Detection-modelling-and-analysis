# app/routes/auth_routes.py
"""Authentication routes: Login, Signup, Logout."""

from flask import (Blueprint, render_template, request,
                   redirect, url_for, session, flash)
from database.db_operations import verify_user, create_user, get_user_by_username
from utils.helpers import validate_login_form, validate_signup_form

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Handle login form."""
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        form = request.form.to_dict()
        is_valid, errors = validate_login_form(form)
        if not is_valid:
            for e in errors:
                flash(e, 'danger')
            return render_template('login.html')

        user = verify_user(form['username'], form['password'])
        if user:
            session.permanent = True
            session['user_id']  = user['user_id']
            session['username'] = user['username']
            session['role']     = user['role']
            flash(f"Welcome back, {user['username']}!", 'success')
            return redirect(url_for('dashboard.index'))
        else:
            flash('Invalid username or password.', 'danger')

    return render_template('login.html')


@auth_bp.route('/signup', methods=['GET', 'POST'])
def signup():
    """Handle new user registration."""
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        form = request.form.to_dict()
        is_valid, errors = validate_signup_form(form)

        if not is_valid:
            for e in errors:
                flash(e, 'danger')
            return render_template('signup.html', form=form)

        # Check username is not already taken
        if get_user_by_username(form['username'].strip()):
            flash('That username is already taken. Please choose another.', 'danger')
            return render_template('signup.html', form=form)

        # Create the user
        create_user(form['username'].strip(), form['password'], form['role'])
        flash(f"Account created successfully! You can now log in.", 'success')
        return redirect(url_for('auth.login'))

    return render_template('signup.html', form={})


@auth_bp.route('/logout')
def logout():
    """Clear session and redirect to login."""
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))


def login_required(f):
    """Decorator to protect routes."""
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated
