# app/routes/data_routes.py
"""
Data Management routes: Insert, Update, Delete transactions.
"""

from flask import (Blueprint, render_template, request,
                   redirect, url_for, flash, jsonify)
from app.routes.auth_routes import login_required
from database.db_operations import (
    get_all_transactions, get_transaction_by_id,
    insert_transaction, update_transaction, delete_transaction,
)
from utils.helpers import validate_transaction_form

data_bp = Blueprint('data', __name__)


@data_bp.route('/')
@login_required
def data_list():
    """Show paginated transaction list."""
    page     = int(request.args.get('page', 1))
    per_page = 20
    offset   = (page - 1) * per_page
    transactions = get_all_transactions(limit=per_page + 1, offset=offset)
    has_next = len(transactions) > per_page
    return render_template(
        'data_management.html',
        transactions=transactions[:per_page],
        page=page,
        has_next=has_next,
    )


@data_bp.route('/add', methods=['POST'])
@login_required
def add_transaction():
    """Insert a new transaction record."""
    form = request.form.to_dict()
    is_valid, errors = validate_transaction_form(form)
    if not is_valid:
        for e in errors:
            flash(e, 'danger')
        return redirect(url_for('data.data_list'))

    txn_id = insert_transaction(form)
    flash(f'Transaction {txn_id} added successfully.', 'success')
    return redirect(url_for('data.data_list'))


@data_bp.route('/edit/<txn_id>', methods=['GET'])
@login_required
def edit_form(txn_id: str):
    """Return transaction data as JSON for modal editing."""
    txn = get_transaction_by_id(txn_id)
    if not txn:
        return jsonify({'error': 'Not found'}), 404
    # Convert datetime for JSON serialization
    if txn.get('transaction_time'):
        txn['transaction_time'] = str(txn['transaction_time'])
    if txn.get('created_at'):
        txn['created_at'] = str(txn['created_at'])
    if txn.get('updated_at'):
        txn['updated_at'] = str(txn['updated_at'])
    return jsonify(txn)


@data_bp.route('/update/<txn_id>', methods=['POST'])
@login_required
def update(txn_id: str):
    """Update an existing transaction."""
    form = request.form.to_dict()
    is_valid, errors = validate_transaction_form(form)
    if not is_valid:
        for e in errors:
            flash(e, 'danger')
        return redirect(url_for('data.data_list'))

    update_transaction(txn_id, form)
    flash(f'Transaction {txn_id} updated successfully.', 'success')
    return redirect(url_for('data.data_list'))


@data_bp.route('/delete/<txn_id>', methods=['POST'])
@login_required
def delete(txn_id: str):
    """Delete a transaction."""
    delete_transaction(txn_id)
    flash(f'Transaction {txn_id} deleted.', 'warning')
    return redirect(url_for('data.data_list'))
