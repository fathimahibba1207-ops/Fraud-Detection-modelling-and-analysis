# app/routes/dashboard_routes.py
"""Dashboard route: central control panel with stats and charts."""

from flask import Blueprint, render_template, redirect, url_for, session
from app.routes.auth_routes import login_required
from database.db_operations import (
    get_dashboard_stats, get_recent_alerts,
    get_fraud_by_payment_method, get_monthly_fraud_trend,
    get_amount_distribution, get_high_risk_users,
)
from data_visualization.charts import (
    bar_fraud_vs_normal, pie_fraud_distribution,
    histogram_amount_distribution, scatter_amount_vs_time,
    heatmap_fraud_patterns, line_monthly_trend,
    bar_fraud_by_payment,
)

dashboard_bp = Blueprint('dashboard', __name__)


@dashboard_bp.route('/')
@login_required
def index():
    """Main dashboard with KPIs and charts."""
    stats          = get_dashboard_stats()
    alerts         = get_recent_alerts(limit=5)
    payment_data   = get_fraud_by_payment_method()
    monthly_data   = get_monthly_fraud_trend()
    txn_data       = get_amount_distribution()
    high_risk_users = get_high_risk_users()

    # Generate charts (saved to static/charts/)
    charts = {
        'bar':       bar_fraud_vs_normal(stats['fraud_count'], stats['normal_count']),
        'pie':       pie_fraud_distribution(stats['fraud_count'], stats['normal_count']),
        'histogram': histogram_amount_distribution(txn_data),
        'scatter':   scatter_amount_vs_time(txn_data),
        'heatmap':   heatmap_fraud_patterns(txn_data),
        'trend':     line_monthly_trend(monthly_data),
        'payment':   bar_fraud_by_payment(payment_data),
    }

    return render_template(
        'dashboard.html',
        stats=stats,
        alerts=alerts,
        charts=charts,
        high_risk_users=high_risk_users,
        username=session.get('username'),
    )
