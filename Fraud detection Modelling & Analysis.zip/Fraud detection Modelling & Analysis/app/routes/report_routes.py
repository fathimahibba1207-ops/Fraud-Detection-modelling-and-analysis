# app/routes/report_routes.py
"""
Reports & Future Analysis routes.
- Monthly/yearly fraud trends
- Risk classification
- High-risk user analysis
- Fraud prevention suggestions
"""

from flask import Blueprint, render_template, jsonify
from app.routes.auth_routes import login_required
from database.db_operations import (
    get_monthly_fraud_trend, get_high_risk_users,
    get_fraud_by_payment_method, get_dashboard_stats,
)
from data_visualization.charts import line_monthly_trend, bar_fraud_by_payment

report_bp = Blueprint('reports', __name__)


def _fraud_prevention_suggestions(stats: dict) -> list:
    """Generate dynamic fraud prevention tips based on stats."""
    suggestions = []
    if stats['fraud_rate'] > 30:
        suggestions.append({
            'severity': 'Critical',
            'icon': '🚨',
            'title': 'High Fraud Rate Detected',
            'message': 'Fraud rate exceeds 30%. Immediate review of transaction approval workflows recommended.',
        })
    if stats['high_risk_count'] > 5:
        suggestions.append({
            'severity': 'High',
            'icon': '⚠️',
            'title': 'High-Risk Transactions Detected',
            'message': f"{stats['high_risk_count']} high-risk transactions detected. Consider step-up authentication for large transfers.",
        })
    suggestions += [
        {'severity': 'Info', 'icon': '🔐', 'title': 'Enable Two-Factor Authentication',
         'message': 'Require 2FA for all transactions above ₹10,000.'},
        {'severity': 'Info', 'icon': '🕐', 'title': 'Monitor Off-Hours Transactions',
         'message': 'Automatically flag transactions made between 10 PM – 5 AM for review.'},
        {'severity': 'Info', 'icon': '📊', 'title': 'Restrict Repeat Offenders',
         'message': 'Monitor users with 3+ fraud-flagged transactions and temporarily limit their accounts.'},
        {'severity': 'Info', 'icon': '🌍', 'title': 'Location Anomaly Detection',
         'message': 'Cross-check transaction location with registered user location for anomalies.'},
    ]
    return suggestions


def _predict_future_trend(monthly_data: list) -> dict:
    """
    Simple linear extrapolation for next 3 months.
    Returns predicted fraud counts and trend direction.
    """
    if len(monthly_data) < 3:
        return {'predictions': [], 'trend': 'Insufficient data'}

    import numpy as np
    counts = [float(row['fraud_count']) for row in monthly_data[-6:]]
    x = np.arange(len(counts))
    slope, intercept = np.polyfit(x, counts, 1)

    predictions = []
    from datetime import datetime, timedelta
    last_month = monthly_data[-1]['month']
    try:
        base = datetime.strptime(last_month, '%Y-%m')
    except Exception:
        base = datetime.now()

    for i in range(1, 4):
        future_month = (base.replace(day=1) + timedelta(days=32 * i)).strftime('%Y-%m')
        predicted_val = max(0, int(slope * (len(counts) + i - 1) + intercept))
        predictions.append({'month': future_month, 'predicted_fraud': predicted_val})

    trend = 'Increasing ↑' if slope > 0.5 else ('Decreasing ↓' if slope < -0.5 else 'Stable →')
    return {'predictions': predictions, 'trend': trend, 'slope': round(slope, 2)}


@report_bp.route('/')
@login_required
def reports():
    """Main reports page."""
    stats        = get_dashboard_stats()
    monthly_data = get_monthly_fraud_trend()
    payment_data = get_fraud_by_payment_method()
    high_risk    = get_high_risk_users()
    suggestions  = _fraud_prevention_suggestions(stats)
    future       = _predict_future_trend(monthly_data)

    charts = {
        'trend':   line_monthly_trend(monthly_data),
        'payment': bar_fraud_by_payment(payment_data),
    }

    risk_summary = {
        'High':   stats.get('high_risk_count', 0),
        'Medium': 0,
        'Low':    max(0, stats.get('total_transactions', 0) - stats.get('high_risk_count', 0)),
    }

    return render_template(
        'reports.html',
        stats=stats,
        monthly_data=monthly_data,
        high_risk_users=high_risk,
        forecasts=future.get('predictions', []),
        tips=suggestions,
        risk_summary=risk_summary,
        charts=charts,
    )


@report_bp.route('/api/monthly')
@login_required
def api_monthly():
    """JSON endpoint for monthly trend data."""
    return jsonify(get_monthly_fraud_trend())


@report_bp.route('/api/stats')
@login_required
def api_stats():
    """JSON endpoint for dashboard stats."""
    return jsonify(get_dashboard_stats())