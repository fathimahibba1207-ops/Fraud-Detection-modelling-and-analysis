# app/routes/prediction_routes.py
"""
Fraud Prediction routes.
Output opens in a new tab (target="_blank" from form submission).
"""

from flask import (Blueprint, render_template, request,
                   redirect, url_for, flash, current_app)
from app.routes.auth_routes import login_required
from ml_pipeline.predictor import predictor
from database.db_operations import insert_transaction, save_prediction_result
from utils.helpers import generate_transaction_id, validate_transaction_form
from datetime import datetime

prediction_bp = Blueprint('predict', __name__)


def _ensure_model_loaded():
    """Lazy-load the ML model on first prediction request."""
    if not predictor.is_loaded:
        cfg = current_app.config
        try:
            predictor.load(cfg['MODEL_PATH'], cfg['SCALER_PATH'])
        except FileNotFoundError:
            return False
    return True


@prediction_bp.route('/', methods=['GET'])
@login_required
def predict_form():
    """Render the prediction input form."""
    return render_template('prediction.html')


@prediction_bp.route('/run', methods=['POST'])
@login_required
def run_prediction():
    """
    Accept form data, run ML prediction, save result,
    then render output.html in a new tab.
    """
    form = request.form.to_dict()
    is_valid, errors = validate_transaction_form(form)
    if not is_valid:
        for e in errors:
            flash(e, 'danger')
        return redirect(url_for('predict.predict_form'))

    if not _ensure_model_loaded():
        flash('ML model not found. Please run train_model.py first.', 'danger')
        return redirect(url_for('predict.predict_form'))

    # Build transaction record
    txn_id = generate_transaction_id()
    txn_data = {
        'transaction_id':     txn_id,
        'user_id':            form.get('user_id', 'Unknown'),
        'transaction_amount': float(form['transaction_amount']),
        'transaction_time':   form.get('transaction_time', datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
        'location':           form.get('location', 'Unknown'),
        'payment_method':     form['payment_method'],
        'transaction_status': 'Normal',  # will be updated after prediction
    }

    # Save raw transaction
    insert_transaction(txn_data)

    # Run prediction
    result = predictor.predict(txn_data)

    # Persist result
    save_prediction_result(
        txn_id,
        result['prediction'],
        result['probability'],
        result['risk_level'],
        result['model_name'],
    )

    # Render output in current response (form uses target="_blank")
    return render_template(
        'output.html',
        txn_id=txn_id,
        transaction=txn_data,
        result=result,
    )


@prediction_bp.route('/result/<txn_id>')
@login_required
def view_result(txn_id: str):
    """View saved prediction result for a transaction."""
    from database.db_operations import get_transaction_by_id
    txn = get_transaction_by_id(txn_id)
    if not txn:
        flash('Transaction not found.', 'danger')
        return redirect(url_for('dashboard.index'))

    result = {
        'prediction':  txn['fraud_prediction'],
        'probability': float(txn['fraud_probability'] or 0),
        'risk_level':  txn['risk_level'],
        'model_name':  'Saved Result',
    }
    return render_template('output.html', txn_id=txn_id, transaction=txn, result=result)
