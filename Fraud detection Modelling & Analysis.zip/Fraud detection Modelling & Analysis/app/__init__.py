# app/__init__.py
from flask import Flask
from flask_mysqldb import MySQL
import os

mysql = MySQL()


def create_app(config_name='default'):
    """Application factory pattern."""
    app = Flask(__name__,
                template_folder='../templates',
                static_folder='../static')

    # Load config
    from app.config import config
    app.config.from_object(config[config_name])

    # Ensure required directories exist
    os.makedirs(app.config['MODEL_DIR'], exist_ok=True)
    os.makedirs(app.config['CHART_DIR'], exist_ok=True)

    # Initialize MySQL
    mysql.init_app(app)

    # Register blueprints
    from app.routes.auth_routes import auth_bp
    from app.routes.dashboard_routes import dashboard_bp
    from app.routes.prediction_routes import prediction_bp
    from app.routes.data_routes import data_bp
    from app.routes.report_routes import report_bp

    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(dashboard_bp, url_prefix='/')
    app.register_blueprint(prediction_bp, url_prefix='/predict')
    app.register_blueprint(data_bp, url_prefix='/data')
    app.register_blueprint(report_bp, url_prefix='/reports')

    return app
