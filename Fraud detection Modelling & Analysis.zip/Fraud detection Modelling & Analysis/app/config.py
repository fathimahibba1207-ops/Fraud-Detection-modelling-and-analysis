# app/config.py
import os

class Config:
    """Base configuration."""
    SECRET_KEY = os.environ.get('SECRET_KEY', 'fraud_detection_secret_key_2024')
    DEBUG = False
    TESTING = False

    # MySQL Database Configuration
    MYSQL_HOST = os.environ.get('MYSQL_HOST', 'localhost')
    MYSQL_USER = os.environ.get('MYSQL_USER', 'root')
    MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD', '#Hf1214158')
    MYSQL_DB = os.environ.get('MYSQL_DB', 'fraud_detection_db')
    MYSQL_PORT = int(os.environ.get('MYSQL_PORT', 3306))

    # Model paths
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    MODEL_DIR = os.path.join(BASE_DIR, 'models')
    MODEL_PATH = os.path.join(MODEL_DIR, 'fraud_model.pkl')
    SCALER_PATH = os.path.join(MODEL_DIR, 'scaler.pkl')

    # Visualization
    CHART_DIR = os.path.join(BASE_DIR, 'static', 'charts')

    # Session timeout (seconds)
    PERMANENT_SESSION_LIFETIME = 1800  # 30 minutes


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}
